#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char **argv){
//int i = argv[1];
int i;
i = atoi(argv[1]);
printf("%s\n",argv[1]);
printf("%d\n",i);
return 0;

}
